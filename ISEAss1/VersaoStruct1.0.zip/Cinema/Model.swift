//
//  Model.swift
//  Cinema
//
//  Created by Rocali on 20/03/2015.
//  Copyright (c) 2015 Rocali. All rights reserved.
//

import Foundation

class Model {
    
    let Cinemas = [Cinema]()
    
    init() {
        Cinema Cinemas = 
    }
    
}