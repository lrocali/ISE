//
//  Movie.swift
//  Cinema
//
//  Created by Rocali on 19/03/2015.
//  Copyright (c) 2015 Rocali. All rights reserved.
//

import Foundation

struct Movie {
    let name : String
}