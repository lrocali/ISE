//
//  CinemaTableViewController.swift
//  Cinema
//
//  Created by Rocali on 19/03/2015.
//  Copyright (c) 2015 Rocali. All rights reserved.
//

import UIKit

class CinemaTableViewController: UITableViewController, UISearchBarDelegate, UISearchDisplayDelegate {
    
    var cinemas = [Cinema]()
    
    var filteredCinemas = [Cinema]()

    override func viewDidLoad() {

        self.cinemas = [Cinema(name: "TCL Chinese Theatre"),
        Cinema(name: "IMAX"),
        Cinema(name: "Futuroscope"),
        Cinema(name: "Golden Village"),
        Cinema(name: "Sol Cinema"),
        Cinema(name: "Busan Cinema Centre"),
        Cinema(name: "The Senator"),
        Cinema(name: "Cinespia"),
        Cinema(name: "CGV Cheongdam Cine City"),
        Cinema(name: "Cinepolis Luxury Cinemas")]
        
        self.tableView.reloadData()
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.searchDisplayController!.searchResultsTableView {
            return self.filteredCinemas.count
        } else {
            return self.cinemas.count
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("cinemaCell") as UITableViewCell
       
        var cinema: Cinema
        
        
        if tableView == self.searchDisplayController!.searchResultsTableView {
            cinema = filteredCinemas[indexPath.row]
        } else {
            cinema = cinemas[indexPath.row]
        }
        
        println(cinema.name)
        
        cell.textLabel!.text = cinema.name
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        return cell
    }
    
    //Search
    func filterContentForSearchText(searchText: String) {
        // Filter the array using the filter method
        self.filteredCinemas = self.cinemas.filter({( cinema: Cinema) -> Bool in
            let stringMatch = cinema.name.rangeOfString(searchText)
            return (stringMatch != nil)
        })
    }
    
    func searchDisplayController(controller: UISearchDisplayController!, shouldReloadTableForSearchString searchCinema: String!) -> Bool {
        self.filterContentForSearchText(searchCinema)
        return true
    }
    
    func searchDisplayController(controller: UISearchDisplayController!, shouldReloadTableForSearchScope searchOption: Int) -> Bool {
        self.filterContentForSearchText(self.searchDisplayController!.searchBar.text)
        return true
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("cinemaDetail", sender: tableView)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "cinemaDetail" {
            let cinemaDetailViewController = segue.destinationViewController as UIViewController
            if sender as UITableView == self.searchDisplayController!.searchResultsTableView {
                let indexPath = self.searchDisplayController!.searchResultsTableView.indexPathForSelectedRow()!
                let destinationTitle = self.filteredCinemas[indexPath.row].name
                cinemaDetailViewController.title = destinationTitle
            } else {
                let indexPath = self.tableView.indexPathForSelectedRow()!
                let destinationTitle = self.cinemas[indexPath.row].name
                cinemaDetailViewController.title = destinationTitle
            }
        }
    }

/*
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 0
    }
*/
   

    
    


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
