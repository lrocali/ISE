//
//  Cinemas.swift
//  Cinema
//
//  Created by Rocali on 20/03/2015.
//  Copyright (c) 2015 Rocali. All rights reserved.
//

import Foundation

enum Cinemas:Int {
    case Cineplex = 1, Dendy, Event, Howard, Hoyts, Indpendet, Palace, TheMovieMasters, Reading, United, Victa, Wallis
    
    var name:String {
        get {
            switch self {
                case .Cineplex return "Cineplex Australia"
                case .Dendy return "Dendy Cinemas"
                case .Event return "Event Cinemas"
                case .Howard return "Howard Cinemas"
                case .Hoyts return "Hoyts"
                case .Indpendet return "Independent Exhibitors"
                case .Palace return "Palace Cinemas"
                case .TheMovieMasters return "The Movie Masters"
                case .Reading return "Reading Cinemas"
                case .Victa return "Victa Cinemas"
                case .Wallis return "Wallis"
                
            }
        }
    }
}